const Product = require("../models/product.model");
const Comments = require("../models/comment.model");

exports.createProduct = async (req, res) => {
  try {
    const { productName, price, details } = req.body;

    const prod = {
      productName,
      price,
      details,
    };
    await Product.create(prod);

    res.status(200).json({
      message: `Your product is added!`,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getAllProducts = async (req, res) => {
  try {
    const products = await Product.find({});
    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

exports.editProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const prod = await Product.findByIdAndUpdate(id, req.body);
    // if product doesnt exist
    if (!prod) {
      return res.status(404).json({ message: `Can't find any product with ID ${id}` });
    }
    res.status(200).json(prod);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.deleteProduct = async (req, res, next) => {
  try {
    const { id } = req.params;
    const prod = await Product.findByIdAndDelete(id);
    if (!prod) {
      res.status(404).json({ message: `Can't find the product with ID ${id}` });
    }
    res.status(200).json({
      message: `product is deleted`,
    });
    next();
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createCommentForProduct = async (req, res) => {
  try {
    const { comment } = req.body;
    const { productId } = req.params;

    const product = await Product.findById(productId);

    if (!product) {
      return res.status(404).json({ message: `Product with ID ${productId} not found` });
    }

    const com = new Comments({ comment, product: product._id });
    await com.save();

    product.comments.push(com._id);
    await product.save();

    res.status(200).json({
      message: `Your comment is added to the product!`,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
