const express = require("express");

const router = express.Router();

const productController = require("../controllers/product.controller");
// product routes

router.post("/add-product", productController.createProduct);
router.get("/all-products", productController.getAllProducts);
router.put("/edit-product/:id", productController.editProduct);
router.post("/delete-product/:id", productController.deleteProduct);

// router for product comments
router.post("/products/:productId/comments", productController.createCommentForProduct);

module.exports = router;
