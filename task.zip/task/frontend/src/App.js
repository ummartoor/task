import React, { useEffect, useState } from "react";
import Axios from "axios";
import { DataGrid } from "@mui/x-data-grid";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
function App() {
  const [data, setData] = useState([]);
  const [productIdToDelete, setProductIdToDelete] = useState("");
  const [productIdToedit, setProductIdToedit] = useState("");
  const [productName, setproductName] = useState("");
  const [price, setPrice] = useState("");
  const [details, setdetails] = useState("");

  const editProduct = () => {
    const dataToUpdate = {
      productName: productName,
      price: price,
      details: details,
    };

    Axios.put(`http://localhost:5000/api/edit-product/${productIdToedit}`, dataToUpdate)
      .then((response) => {
        console.log("Product updated:", response);
        Axios.get("http://localhost:5000/api/all-products")
          .then((response) => {
            if (response.data) {
              setData(response.data);
            }
          })
          .catch((error) => {
            console.error("Error fetching data:", error);
          });
      })
      .catch((error) => {
        console.error("Error editing product:", error);
      });
  };

  const deleteProduct = () => {
    Axios.post(`http://localhost:5000/api/delete-product/${productIdToDelete}`)
      .then((response) => {
        console.log("🚀 ~ file: App.js:13 ~ .then ~ response:", response);
        Axios.get("http://localhost:5000/api/all-products")
          .then((response) => {
            if (response.data) {
              setData(response.data);
            }
          })
          .catch((error) => {
            console.error("Error fetching data:", error);
          });
      })
      .catch((error) => {
        console.error("Error deleting product:", error);
      });
  };
  useEffect(() => {
    Axios.get("http://localhost:5000/api/all-products")
      .then((response) => {
        if (response.data) {
          setData(response.data);
        }
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  const columns = [
    { field: "_id", headerName: "ID", width: 300 },
    { field: "productName", headerName: "Product name", width: 200 },
    { field: "price", headerName: "Product price", width: 200 },
  ];

  return (
    <div className="App">
      <h2>All products</h2>
      <div style={{ height: 400, width: "70%" }}>
        <DataGrid
          rows={data}
          columns={columns}
          pageSize={5}
          checkboxSelection
          getRowId={(row) => row._id} // Specify the custom ID extraction function
        />
      </div>
      <h2>Delete a Product</h2>
      <div>
        <Box
          component="form"
          sx={{
            "& > :not(style)": { m: 1, width: "25ch" },
          }}
          noValidate
          autoComplete="off"
        >
          <TextField id="outlined-basic" label="Enter product ID to delete" variant="outlined" value={productIdToDelete} onChange={(e) => setProductIdToDelete(e.target.value)} />
          <button onClick={deleteProduct}>Delete Product</button>
        </Box>
      </div>

      <h2>Edit a product</h2>
      <div>
        <Box
          component="form"
          sx={{
            "& > :not(style)": { m: 1, width: "25ch" },
          }}
          noValidate
          autoComplete="off"
        >
          <TextField id="outlined-basic" label="Enter product ID to delete" variant="outlined" value={productIdToedit} onChange={(e) => setProductIdToedit(e.target.value)} />
          <TextField id="outlined-basic" label="Enter product name" variant="outlined" value={productName} onChange={(e) => setproductName(e.target.value)} />
          <TextField id="outlined-basic" label="Enter product price" variant="outlined" value={price} onChange={(e) => setPrice(e.target.value)} />
          <TextField id="outlined-basic" label="Enter product details" variant="outlined" value={details} onChange={(e) => setdetails(e.target.value)} />
          <button onClick={editProduct}>Edit Product</button>
        </Box>
      </div>
    </div>
  );
}

export default App;
