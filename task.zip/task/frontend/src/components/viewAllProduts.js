import React from "react";

function viewAllProduts() {
  return (
    <div>
      <h1>alllll</h1>
    </div>
  );
}

export default viewAllProduts;
